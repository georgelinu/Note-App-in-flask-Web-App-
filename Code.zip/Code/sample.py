import flask as flask
from flask import Response
from flask import Flask,flash
from flask import request
from flask import render_template
import json
import urllib.request
import MySQLdb 

conn = MySQLdb.connect("localhost","root","root","web" ) 
cursor = conn.cursor() 

app = flask.Flask(__name__)

@app.route('/')
def index():
    return flask.render_template("index.html")

@app.route('/login',methods = ['GET','POST'])
def login():
    uname = "user"
    password = "user"
    var1 = flask.request.form.get('username')
    var2 = flask.request.form.get('pass')
    if uname == var1 and password == var2:
        return flask.render_template("about.html")
    else:
        return flask.render_template("index.html")

    
@app.route('/uploader', methods = ['GET', 'POST'])
def upload_file():
    return flask.render_template("success.html")


@app.route('/notes', methods = ['GET', 'POST'])
def video_fun():

    cursor.execute("select * from notes") 
    data = cursor.fetchall() #data from database 
    return flask.render_template("notes.html", value=data)

@app.route('/addnote', methods = ['GET', 'POST'])
def addnote_fun():
    titles = flask.request.form.get('notetitle')
    contents = flask.request.form.get('notetextarea')
    date_time = flask.request.form.get('notedatetime')
    la = " "
    lo = " "
    # la = 56.8777
    # lo = 14.8091
        # insert data
    sql = "INSERT INTO notes (title, content, datetime, lati, longi) VALUES (%s, %s, %s, %s, %s)"
    val = (titles, contents, date_time, la, lo)
    cursor.execute(sql, val)
    conn.commit() # apply changes
    return flask.render_template("success.html")

@app.route('/editnote', methods = ['GET', 'POST'])
def edit_fun():
    sid = request.args.get("txt1")
    titl = request.args.get("txt2")
    cont = request.args.get("txt3")
    dtm = request.args.get("txt4")
    data = {'id': sid, 'tit': titl, 'con': cont, 'dtime': dtm}
    return flask.render_template("editnotes.html", value=data)

@app.route('/editt', methods = ['GET', 'POST'])
def editt_fun():
    sid = flask.request.form.get('nid')
    titles = flask.request.form.get('notetitle')
    contents = flask.request.form.get('notetextarea')
    dt_tm = flask.request.form.get('notedatetime')
    sql = "UPDATE notes SET title = %s, content = %s, datetime = %s WHERE slno = %s"
    val = (titles, contents, dt_tm, sid)
    cursor.execute(sql, val)
    conn.commit()
    return flask.render_template("success.html")

@app.route('/delnote', methods = ['GET', 'POST'])
def del_fun():
    sid = request.args.get("txt1")
    titl = request.args.get("txt2")
    cont = request.args.get("txt3")
    dtm = request.args.get("txt4")
    data = {'id': sid, 'tit': titl, 'con': cont, 'dtime': dtm}
    return flask.render_template("deletenotes.html", value=data)

@app.route('/delete', methods = ['GET', 'POST'])
def delete_fun():
    sid = flask.request.form.get('nid')
    
    sql = "DELETE FROM notes WHERE slno = %s"
    val = (sid,)
    cursor.execute(sql, val)
    conn.commit()
    return flask.render_template("success.html")

@app.route('/about', methods = ['GET', 'POST'])
def about_fun():
    return flask.render_template("about.html")

@app.route('/weather', methods =['POST', 'GET']) 
def weather(): 
    if request.method == 'POST': 
        city = request.form['city'] 
    else: 
        city = 'Vaxjo'
  
    api = '********************************'
  
    # source contain json data from api 
    source = urllib.request.urlopen('http://api.openweathermap.org/data/2.5/weather?q='+city+'&appid='+api).read() 
  
    # converting JSON data to a dictionary 
    list_of_data = json.loads(source) 
  
    # data for variable list_of_data 
    data = { 
        "country_code": str(list_of_data['sys']['country']), 
        "city_name": str(list_of_data['name']), 
        # "weadesc": str(list_of_data['weather']['description']), 
        "coordinate": str(list_of_data['coord']['lon']) + ' & ' + str(list_of_data['coord']['lat']), 
        "temp": str(list_of_data['main']['temp']) + 'k', 
        "temp_cel": tocelcius(list_of_data['main']['temp']) + '°C',
        "pressure": str(list_of_data['main']['pressure']), 
        "feelslike": tocelcius(list_of_data['main']['feels_like']) + '°C',
        "humidity": str(list_of_data['main']['humidity']), 
    } 
    print(data) 
    return render_template('weather.html', data = data) 
      
def tocelcius(temp):
    return str(round(float(temp) - 273.16,2))
    
if __name__ == '__main__':
    app.run(debug = True)
